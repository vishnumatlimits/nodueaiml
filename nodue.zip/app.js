const express = require('express');
const path = require('path');
const session = require('express-session');
const morgan = require('morgan');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(morgan('dev'));
app.use(
  session({
    secret: 'replace-this-secret',
    resave: false,
    saveUninitialized: false,
  }),
);

mongoose
  .connect(process.env.MONGO_URI, {
    dbName: 'nodue',
  })
  .then(async () => {
    // eslint-disable-next-line no-console
    console.log('Connected to MongoDB');

    // Best-effort cleanup of old unique index on subjectCode, if it exists
    try {
      const SubjectModel = mongoose.models.Subject;
      if (SubjectModel && SubjectModel.collection) {
        await SubjectModel.collection.dropIndex('subjectCode_1');
      }
    } catch (err) {
      if (err && err.codeName !== 'IndexNotFound') {
        // eslint-disable-next-line no-console
        console.error('Failed to drop legacy subjectCode index', err);
      }
    }
  })
  .catch((err) => {
    // eslint-disable-next-line no-console
    console.error('MongoDB connection error', err);
  });

const studentSchema = new mongoose.Schema(
  {
    rollNumber: { type: String, required: true, unique: true, trim: true },
    name: { type: String, required: true, trim: true },
    branch: { type: String, trim: true },
    department: { type: String, trim: true },
    year: { type: String, trim: true },
    section: { type: String, trim: true },
    semester: { type: String, trim: true },
    mentorFacultyId: { type: String, trim: true },
    mentorNotes: { type: String, trim: true },
  },
  { timestamps: true },
);

studentSchema.index({ rollNumber: 1 }, { unique: true });
const Student = mongoose.model('Student', studentSchema);

const facultySchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    facultyId: { type: String, required: true, unique: true, trim: true },
    password: { type: String, required: true },
    department: { type: String, required: true, trim: true },
    role: { type: String, enum: ['faculty', 'hod'], default: 'faculty' },
  },
  { timestamps: true },
);

facultySchema.index({ facultyId: 1 }, { unique: true });
const Faculty = mongoose.model('Faculty', facultySchema);

const subjectSchema = new mongoose.Schema(
  {
    // Subject code is no longer globally unique; it can repeat across branches
    subjectCode: { type: String, required: true, trim: true },
    subjectName: { type: String, required: true, trim: true },
    // Single owning branch for this subject offering
    branch: { type: String, trim: true },
    // Optional historical support for multi-branch subjects (not used for new records)
    branches: [{ type: String, trim: true }],
    year: { type: String, trim: true },
    semester: { type: String, trim: true },
    // Single faculty per subject offering (stored as array for compatibility)
    facultyIds: [{ type: String, trim: true }],
  },
  { timestamps: true },
);

// Enforce uniqueness per subject offering: same code can repeat across branches
subjectSchema.index({ subjectCode: 1, branch: 1 }, { unique: true });
const Subject = mongoose.model('Subject', subjectSchema);

// Request schema: persists all clearance/assignment requests
const requestSchema = new mongoose.Schema(
  {
    rollNumber: { type: String, required: true, index: true },
    studentName: { type: String, trim: true },
    subjectCode: { type: String, trim: true },
    subjectName: { type: String, trim: true },
    facultyId: { type: String, trim: true },
    department: { type: String, trim: true },
    branch: { type: String, trim: true },
    year: { type: String, trim: true },
    semester: { type: String, trim: true },
    section: { type: String, trim: true },
    reason: { type: String, trim: true },
    status: { type: String, default: 'Pending Faculty' },
    assignment1: { type: Boolean, default: false },
    assignment2: { type: Boolean, default: false },
    facultyNote: { type: String, trim: true },
    adminNote: { type: String, trim: true },
  },
  { timestamps: true },
);

const Request = mongoose.model('Request', requestSchema);

// Ensure that for a given subject, all relevant students have a Request row
const ensureRequestsForSubject = async (subject) => {
  if (!subject) return;

  const { subjectCode, subjectName, branch, branches, year, semester, facultyIds } = subject;

  // Support mapping a subject to one or many branches
  const branchList = Array.isArray(branches) && branches.length
    ? branches.filter(Boolean)
    : (branch ? [branch] : []);

  if (!subjectCode || !branchList.length || !year || !semester) return;

  try {
    const students = await Student.find({ branch: { $in: branchList }, year, semester }).lean();
    if (!students.length) return;

    const rollNumbers = students.map((s) => s.rollNumber);

    const existing = await Request.find({
      subjectCode,
      rollNumber: { $in: rollNumbers },
    }).lean();

    const existingKeys = new Set(existing.map((r) => `${r.rollNumber}`));
    const defaultFacultyId =
      Array.isArray(facultyIds) && facultyIds.length ? facultyIds[0] : null;

    const toInsert = [];
    students.forEach((stu) => {
      if (!existingKeys.has(stu.rollNumber)) {
        toInsert.push({
          rollNumber: stu.rollNumber,
          studentName: stu.name,
          subjectCode,
          subjectName,
          facultyId: defaultFacultyId,
          department: stu.department || stu.branch || '',
          branch: stu.branch || '',
          year: stu.year || '',
          semester: stu.semester || '',
          section: stu.section || '',
          reason: `No-due clearance for ${subjectName}`,
          status: 'Pending Faculty',
          assignment1: false,
          assignment2: false,
          facultyNote: '',
          adminNote: '',
        });
      }
    });

    if (toInsert.length) {
      await Request.insertMany(toInsert);
    }
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to ensure requests for subject', err);
  }
};

// Keep Request.facultyId in sync with the subject's assigned faculty
const syncSubjectRequestsFaculty = async (subject) => {
  if (!subject) return;

  const { subjectCode, branch, year, semester, facultyIds } = subject;
  const defaultFacultyId =
    Array.isArray(facultyIds) && facultyIds.length ? facultyIds[0] : null;

  if (!subjectCode || !defaultFacultyId) return;

  const filter = { subjectCode };
  if (branch) filter.branch = branch;
  if (year) filter.year = year;
  if (semester) filter.semester = semester;

  try {
    await Request.updateMany(filter, { $set: { facultyId: defaultFacultyId } });
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to sync subject request faculty', err);
  }
};

app.use((req, res, next) => {
  res.locals.user = req.session.user;
  next();
});

const ensureRole = (...roles) => (req, res, next) => {
  const user = req.session.user;
  if (!user || !roles.includes(user.role)) {
    return res.redirect('/login');
  }
  return next();
};

const loadCurrentFaculty = async (req) => {
  if (!req.session.user || !req.session.user.facultyId) return null;
  try {
    return await Faculty.findOne({ facultyId: req.session.user.facultyId }).lean();
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to load faculty profile', err);
    return null;
  }
};

const renderFacultyDashboard = async (req, res, extras = {}) => {
  const self = await loadCurrentFaculty(req);
  if (!self) {
    return res.status(404).render('staffLogin', { error: 'Profile not found. Please log in again.' });
  }

  // Ensure requests exist for all subjects handled by this faculty
  try {
    const subjectsForFaculty = await Subject.find({ facultyIds: self.facultyId }).lean();
    // Sequential to avoid overwhelming DB; typically small per-faculty
    for (const subj of subjectsForFaculty) {
      // This will create missing Request rows for all matching students
      // based on subject branch/year/semester
      // (no-op if everything already exists)
      // eslint-disable-next-line no-await-in-loop
      await ensureRequestsForSubject(subj);
    }
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to backfill requests for faculty subjects', err);
  }

  // Load requests for this faculty from DB
  let myRequests = [];
  try {
    myRequests = await Request.find({
      $or: [
        { facultyId: self.facultyId },
        { facultyId: { $exists: false } },
        { facultyId: null },
      ],
    })
      .sort({ createdAt: -1 })
      .lean();

    // decorate with id for templates
    myRequests = myRequests.map((r) => ({ ...r, id: r._id.toString() }));
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to load faculty requests', err);
  }

  // Split into subject-based vs general requests
  const subjectRequests = myRequests.filter((r) => r.subjectCode);
  const generalRequests = myRequests.filter((r) => !r.subjectCode);

  // Group subject-wise for tabular display (like approval sheets)
  const subjectGroupsMap = new Map();
  subjectRequests.forEach((r) => {
    const key = r.subjectCode || r.subjectName || 'Unknown';
    if (!subjectGroupsMap.has(key)) {
      subjectGroupsMap.set(key, {
        subjectCode: r.subjectCode || '',
        subjectName: r.subjectName || 'Unknown Subject',
        rows: [],
      });
    }
    subjectGroupsMap.get(key).rows.push(r);
  });

  // Convert to array and sort subjects and rows by roll number
  const subjectGroups = Array.from(subjectGroupsMap.values())
    .sort((a, b) => (a.subjectCode || '').localeCompare(b.subjectCode || ''));

  subjectGroups.forEach((group) => {
    group.rows.sort((a, b) => {
      const ra = (a.rollNumber || '').toString();
      const rb = (b.rollNumber || '').toString();
      return ra.localeCompare(rb);
    });
  });

  const payload = {
    pending: generalRequests.filter((r) => r.status === 'Pending Faculty'),
    all: generalRequests,
    subjectGroups,
    self,
    profileError: extras.profileError || null,
    profileSuccess: extras.profileSuccess || null,
  };

  return res.render('facultyDashboard', payload);
};

const renderHodDashboard = async (req, res, extras = {}) => {
  const self = await loadCurrentFaculty(req);
  if (!self) {
    return res.status(404).render('staffLogin', { error: 'Profile not found. Please log in again.' });
  }

  // Ensure requests exist for all subjects handled by this HOD as a faculty member
  try {
    const subjectsForFaculty = await Subject.find({ facultyIds: self.facultyId }).lean();
    for (const subj of subjectsForFaculty) {
      // eslint-disable-next-line no-await-in-loop
      await ensureRequestsForSubject(subj);
    }
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to backfill requests for HOD subjects', err);
  }

  // Load subject-wise requests for this HOD acting strictly as assigned faculty
  let subjectGroups = [];
  try {
    let myRequests = await Request.find({
      facultyId: self.facultyId,
    })
      .sort({ createdAt: -1 })
      .lean();

    myRequests = myRequests.map((r) => ({ ...r, id: r._id.toString() }));

    const subjectRequests = myRequests.filter((r) => r.subjectCode);

    const subjectGroupsMap = new Map();
    subjectRequests.forEach((r) => {
      const key = r.subjectCode || r.subjectName || 'Unknown';
      if (!subjectGroupsMap.has(key)) {
        subjectGroupsMap.set(key, {
          subjectCode: r.subjectCode || '',
          subjectName: r.subjectName || 'Unknown Subject',
          rows: [],
        });
      }
      subjectGroupsMap.get(key).rows.push(r);
    });

    subjectGroups = Array.from(subjectGroupsMap.values()).sort((a, b) =>
      (a.subjectCode || '').localeCompare(b.subjectCode || ''),
    );

    subjectGroups.forEach((group) => {
      group.rows.sort((a, b) => {
        const ra = (a.rollNumber || '').toString();
        const rb = (b.rollNumber || '').toString();
        return ra.localeCompare(rb);
      });
    });
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to load HOD subject-wise requests', err);
  }

  let students = [];
  let faculties = [];
  let subjects = [];
  let dataError = null;
  let pendingRequests = [];
  let allRequests = [];

  try {
    students = await Student.find().sort({ rollNumber: 1 }).lean();
    faculties = await Faculty.find().sort({ facultyId: 1 }).lean();
    subjects = await Subject.find().sort({ subjectCode: 1 }).lean();

    allRequests = await Request.find().sort({ createdAt: -1 }).lean();
    allRequests = allRequests.map((r) => ({ ...r, id: r._id.toString() }));
    pendingRequests = allRequests.filter((r) => r.status === 'Pending HOD');
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to load HOD data', err);
    dataError = 'Could not load all records right now.';
  }

  const payload = {
    pending: pendingRequests,
    all: allRequests,
    students,
    faculties,
    subjects,
    self,
    subjectGroups,
    dataError,
    profileError: extras.profileError || null,
    profileSuccess: extras.profileSuccess || null,
    initialPanel: extras.initialPanel || null,
  };

  return res.render('HODDashboard', payload);
};

app.get('/', (req, res) => {
  const user = req.session.user;
  if (user && user.role === 'faculty') {
    return res.redirect('/faculty');
  }
  if (user && user.role === 'hod') {
    return res.redirect('/hod');
  }
  return res.render('login', { error: null, searchError: null, searchResult: null });
});

app.get('/login', (req, res) => {
  const user = req.session.user;
  if (user && user.role === 'faculty') {
    return res.redirect('/faculty');
  }
  if (user && user.role === 'hod') {
    return res.redirect('/hod');
  }
  return res.render('staffLogin', { error: null });
});

app.post('/login', async (req, res) => {
  try {
    const staffId = (req.body.staffId || '').trim();
    const password = (req.body.password || '').trim();
    if (!staffId || !password) {
      return res
        .status(400)
        .render('staffLogin', {
          error: 'Staff ID and password are required for faculty / HOD.',
        });
    }

    const faculty = await Faculty.findOne({ facultyId: staffId }).lean();
    if (!faculty) {
      return res
        .status(401)
        .render('staffLogin', { error: 'Invalid staff credentials.' });
    }

    const validPassword = await bcrypt.compare(password, faculty.password);
    if (!validPassword) {
      return res
        .status(401)
        .render('staffLogin', { error: 'Invalid staff credentials.' });
    }

    const role = faculty.role || 'faculty';
    req.session.user = { name: faculty.name, facultyId: faculty.facultyId, role };
    return res.redirect(role === 'hod' ? '/hod' : '/faculty');
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Login failed', err);
    return res.status(500).render('staffLogin', {
      error: 'Could not sign in right now. Please try again.',
    });
  }
});

app.post('/student/search', async (req, res) => {
  const rollNumber = (req.body.rollNumber || '').trim();
  if (!rollNumber) {
    return res.status(400).render('login', {
      error: null,
      searchError: 'Roll number is required to search.',
      searchResult: null,
    });
  }

  try {
    const student = await Student.findOne({ rollNumber }).lean();
    if (!student) {
      return res.status(404).render('login', {
        error: null,
        searchError: 'No student found for this roll number.',
        searchResult: null,
      });
    }

    const subjectFilter = {
      year: student.year || undefined,
      semester: student.semester || undefined,
    };

    if (student.branch) {
      subjectFilter.$or = [
        { branch: student.branch },
        { branches: student.branch },
      ];
    }

    const subjects = await Subject.find(subjectFilter)
      .sort({ subjectCode: 1 })
      .lean();

    // Ensure there is a clearance request for each subject registered by this student
    const subjectCodes = subjects.map((s) => s.subjectCode);

    const existingRequests = await Request.find({
      rollNumber,
      subjectCode: { $in: subjectCodes },
    }).lean();

    const existingByCode = new Map(existingRequests.map((r) => [r.subjectCode, r]));

    const newRequests = [];
    subjects.forEach((subj) => {
      if (!existingByCode.has(subj.subjectCode)) {
        const facultyId =
          Array.isArray(subj.facultyIds) && subj.facultyIds.length ? subj.facultyIds[0] : null;
        newRequests.push({
          rollNumber,
          studentName: student.name,
          subjectCode: subj.subjectCode,
          subjectName: subj.subjectName,
          facultyId,
          department: student.department || student.branch || '',
          branch: student.branch || '',
          year: student.year || '',
          semester: student.semester || '',
          section: student.section || '',
          reason: `No-due clearance for ${subj.subjectName}`,
          status: 'Pending Faculty',
          assignment1: false,
          assignment2: false,
          facultyNote: '',
          adminNote: '',
        });
      }
    });

    if (newRequests.length) {
      await Request.insertMany(newRequests);
    }

    const allRequests = await Request.find({
      rollNumber,
      subjectCode: { $in: subjectCodes },
    }).lean();

    const requestsByCode = new Map(allRequests.map((r) => [r.subjectCode, r]));

    const facultyIds = Array.from(
      new Set(
        allRequests
          .map((r) => r.facultyId)
          .filter(Boolean),
      ),
    );
    const facultyMap = new Map();
    if (facultyIds.length) {
      const facs = await Faculty.find({ facultyId: { $in: facultyIds } }).lean();
      facs.forEach((f) => {
        facultyMap.set(f.facultyId, f.name);
      });
    }

    const subjectStatuses = subjects.map((subj) => {
      const match = requestsByCode.get(subj.subjectCode);
      const assignment1 = !!(match && match.assignment1);
      const assignment2 = !!(match && match.assignment2);
      const facultyName = match && match.facultyId ? facultyMap.get(match.facultyId) : null;

      return {
        subjectCode: subj.subjectCode,
        subjectName: subj.subjectName,
        assignment1,
        assignment2,
        facultyName,
        facultyNote: match && match.facultyNote ? match.facultyNote : '',
      };
    });

    return res.render('login', {
      error: null,
      searchError: null,
      searchResult: {
        rollNumber,
        student,
        subjects: subjectStatuses,
      },
    });
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Student search failed', err);
    return res.status(500).render('login', {
      error: null,
      searchError: 'Unable to fetch status right now. Please try again.',
      searchResult: null,
    });
  }
});

app.get('/faculty/profile', ensureRole('faculty'), async (req, res) =>
  renderFacultyDashboard(req, res, { profileError: null, profileSuccess: null }),
);

app.post('/faculty/profile', ensureRole('faculty'), async (req, res) => {
  const current = await loadCurrentFaculty(req);
  if (!current) {
    return res.status(404).render('staffLogin', {
      error: 'Profile not found. Please log in again.',
    });
  }

  const name = (req.body.name || '').trim();
  const newFacultyId = (req.body.facultyId || '').trim();
  const password = (req.body.password || '').trim();

  if (!name && !newFacultyId && !password) {
    return renderFacultyDashboard(req, res, {
      profileError: 'Provide at least one field to update.',
      profileSuccess: null,
    });
  }

  const update = {};
  if (name) update.name = name;
  if (newFacultyId) update.facultyId = newFacultyId;
  if (password) {
    try {
      update.password = await bcrypt.hash(password, 10);
    } catch (err) {
      // eslint-disable-next-line no-console
      console.error('Failed to hash password', err);
    }
  }

  try {
    const updated = await Faculty.findOneAndUpdate(
      { facultyId: current.facultyId },
      { $set: update },
      { new: true },
    ).lean();

    if (!updated) {
      return res.status(404).render('staffLogin', {
        error: 'Profile not found. Please log in again.',
      });
    }

    req.session.user.name = updated.name;
    req.session.user.facultyId = updated.facultyId;

    return renderFacultyDashboard(req, res, {
      profileError: null,
      profileSuccess: 'Profile updated successfully.',
    });
  } catch (err) {
    if (err?.code === 11000) {
      return renderFacultyDashboard(req, res, {
        profileError: 'Faculty ID already exists. Choose another.',
        profileSuccess: null,
      });
    }
    // eslint-disable-next-line no-console
    console.error('Failed to update faculty profile', err);
    return renderFacultyDashboard(req, res, {
      profileError: 'Could not update profile right now. Please try again.',
      profileSuccess: null,
    });
  }
});

app.get('/hod/profile', ensureRole('hod'), async (req, res) =>
  renderHodDashboard(req, res, { initialPanel: 'profile' }),
);

app.post('/hod/profile', ensureRole('hod'), async (req, res) => {
  const current = await loadCurrentFaculty(req);
  if (!current) {
    return res.status(404).render('staffLogin', {
      error: 'Profile not found. Please log in again.',
    });
  }

  const name = (req.body.name || '').trim();
  const newFacultyId = (req.body.facultyId || '').trim();
  const password = (req.body.password || '').trim();

  if (!name && !newFacultyId && !password) {
    return renderHodDashboard(req, res, {
      profileError: 'Provide at least one field to update.',
      profileSuccess: null,
      initialPanel: 'profile',
    });
  }

  const update = {};
  if (name) update.name = name;
  if (newFacultyId) update.facultyId = newFacultyId;
  if (password) {
    try {
      update.password = await bcrypt.hash(password, 10);
    } catch (err) {
      // eslint-disable-next-line no-console
      console.error('Failed to hash password', err);
    }
  }

  try {
    const updated = await Faculty.findOneAndUpdate(
      { facultyId: current.facultyId },
      { $set: update },
      { new: true },
    ).lean();

    if (!updated) {
      return res.status(404).render('staffLogin', {
        error: 'Profile not found. Please log in again.',
      });
    }

    req.session.user.name = updated.name;
    req.session.user.facultyId = updated.facultyId;

    return renderHodDashboard(req, res, {
      profileError: null,
      profileSuccess: 'Profile updated successfully.',
      initialPanel: 'profile',
    });
  } catch (err) {
    if (err?.code === 11000) {
      return renderHodDashboard(req, res, {
        profileError: 'Faculty ID already exists. Choose another.',
        profileSuccess: null,
        initialPanel: 'profile',
      });
    }
    // eslint-disable-next-line no-console
    console.error('Failed to update HOD profile', err);
    return renderHodDashboard(req, res, {
      profileError: 'Could not update profile right now. Please try again.',
      profileSuccess: null,
      initialPanel: 'profile',
    });
  }
});

app.post('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/login');
  });
});

app.get('/student', ensureRole('student'), async (req, res) => {
  const { name } = req.session.user;
  let myRequests = [];
  try {
    myRequests = await Request.find({ studentName: name })
      .sort({ createdAt: -1 })
      .lean();
    myRequests = myRequests.map((r) => ({ ...r, id: r._id.toString() }));
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to load student requests', err);
  }
  res.render('studentDashboard', { requests: myRequests });
});

app.post('/student/requests', ensureRole('student'), async (req, res) => {
  const { department, reason } = req.body;
  const { name } = req.session.user;
  if (!department || !reason) {
    let myRequests = [];
    try {
      myRequests = await Request.find({ studentName: name })
        .sort({ createdAt: -1 })
        .lean();
      myRequests = myRequests.map((r) => ({ ...r, id: r._id.toString() }));
    } catch (err) {
      // eslint-disable-next-line no-console
      console.error('Failed to load student requests', err);
    }
    return res.status(400).render('studentDashboard', {
      requests: myRequests,
      error: 'Department and reason are required.',
    });
  }

  try {
    await Request.create({
      rollNumber: '',
      studentName: name,
      department,
      reason,
      status: 'Pending Faculty',
      facultyNote: '',
      adminNote: '',
    });
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to create student request', err);
  }

  return res.redirect('/student');
});

app.get('/faculty', ensureRole('faculty', 'hod'), async (req, res) => renderFacultyDashboard(req, res));

// Subject assignment toggles per student: two assignments per subject
// NOTE: this route must be defined BEFORE the generic :action route below
app.post('/faculty/requests/:id/assignments', ensureRole('faculty', 'hod'), async (req, res) => {
  const { id } = req.params;
  let request;
  try {
    request = await Request.findById(id);
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to load request for assignments', err);
  }
  if (!request) return res.status(404).send('Request not found');

  // interpret checkbox values
  const assignment1 = !!req.body.assignment1;
  const assignment2 = !!req.body.assignment2;

  request.assignment1 = assignment1;
  request.assignment2 = assignment2;
  request.facultyNote = (req.body.facultyNote || '').trim();

  if (assignment1 && assignment2) {
    request.status = 'Approved';
    if (!request.facultyNote) request.facultyNote = 'Assignments 1 & 2 cleared';
  } else if (!assignment1 && !assignment2) {
    request.status = 'Pending Faculty';
  } else {
    request.status = 'Partially Cleared';
  }

  try {
    await request.save();
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to update assignment status', err);
  }

  return res.redirect('/faculty#student-data');
});

// Bulk update assignments and remarks for many students at once
app.post('/faculty/requests/bulk-assignments', ensureRole('faculty', 'hod'), async (req, res) => {
  const { assignments } = req.body;
  if (!assignments || typeof assignments !== 'object') {
    return res.redirect('/faculty#student-data');
  }

  try {
    const ops = [];
    Object.entries(assignments).forEach(([id, data]) => {
      if (!data) return;
      const assignment1 = !!data.assignment1;
      const assignment2 = !!data.assignment2;
      let facultyNote = (data.facultyNote || '').trim();

      const update = {
        assignment1,
        assignment2,
        facultyNote,
      };

      if (assignment1 && assignment2) {
        update.status = 'Approved';
        if (!facultyNote) update.facultyNote = 'Assignments 1 & 2 cleared';
      } else if (!assignment1 && !assignment2) {
        update.status = 'Pending Faculty';
      } else {
        update.status = 'Partially Cleared';
      }

      ops.push({
        updateOne: {
          filter: { _id: id },
          update: { $set: update },
        },
      });
    });

    if (ops.length) {
      await Request.bulkWrite(ops);
    }
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to bulk update assignments', err);
  }

  return res.redirect('/faculty#student-data');
});

// Legacy approve/deny for non-subject requests (still supported)
app.post('/faculty/requests/:id/:action', ensureRole('faculty', 'hod'), async (req, res) => {
  const { id, action } = req.params;
  const { note } = req.body;
  let request;
  try {
    request = await Request.findById(id);
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to load request for faculty action', err);
  }
  if (!request) return res.status(404).send('Request not found');
  if (request.status !== 'Pending Faculty') return res.status(400).send('Request already processed');

  if (action === 'approve') {
    request.status = 'Approved';
    request.facultyNote = note || 'Approved by faculty';
  } else if (action === 'deny') {
    request.status = 'Rejected by Faculty';
    request.facultyNote = note || 'Denied by faculty';
  } else {
    return res.status(400).send('Invalid action');
  }

  try {
    await request.save();
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to update faculty request status', err);
  }

  return res.redirect('/faculty');
});

app.get('/hod', ensureRole('hod'), async (req, res) => renderHodDashboard(req, res));

app.post('/hod/requests/:id/:action', ensureRole('hod'), async (req, res) => {
  const { id, action } = req.params;
  const { note } = req.body;
  let request;
  try {
    request = await Request.findById(id);
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to load request for HOD action', err);
  }
  if (!request) return res.status(404).send('Request not found');
  if (request.status !== 'Pending HOD') return res.status(400).send('Request already processed');

  if (action === 'approve') {
    request.status = 'Approved';
    request.adminNote = note || 'Cleared by HOD';
  } else if (action === 'deny') {
    request.status = 'Rejected by HOD';
    request.adminNote = note || 'Denied by HOD';
  } else {
    return res.status(400).send('Invalid action');
  }

  try {
    await request.save();
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to update HOD request status', err);
  }

  return res.redirect('/hod');
});

app.post('/hod/students', ensureRole('hod'), async (req, res) => {
  const {
    rollNumber,
    name,
    branch,
    department,
    year,
    semester,
    section,
    mentorFacultyId,
    mentorNotes,
  } = req.body;
  if (!rollNumber || !name) {
    return res.redirect('/hod#manage-students');
  }
  try {
    await Student.findOneAndUpdate(
      { rollNumber: rollNumber.trim() },
      {
        rollNumber: rollNumber.trim(),
        name: name.trim(),
        branch: branch?.trim() || undefined,
        year,
        section,
        department,
        semester: semester?.trim() || undefined,
        mentorFacultyId: mentorFacultyId?.trim() || undefined,
        mentorNotes: mentorNotes?.trim() || undefined,
      },
      { upsert: true, new: true, setDefaultsOnInsert: true },
    );
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to upsert student', err);
  }
  return res.redirect('/hod#manage-students');
});

app.post('/hod/students/:roll/update', ensureRole('hod'), async (req, res) => {
  const { roll } = req.params;
  const {
    rollNumber,
    name,
    branch,
    department,
    year,
    semester,
    section,
    mentorFacultyId,
    mentorNotes,
  } = req.body;
  try {
    await Student.findOneAndUpdate(
      { rollNumber: roll },
      {
        rollNumber: rollNumber?.trim() || roll,
        name: name?.trim(),
        branch: branch?.trim() || undefined,
        year,
        section,
        department,
        semester: semester?.trim() || undefined,
        mentorFacultyId: mentorFacultyId?.trim() || undefined,
        mentorNotes: mentorNotes?.trim() || undefined,
      },
      { new: true },
    );
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to update student', err);
  }
  return res.redirect('/hod#manage-students');
});

app.post('/hod/students/:roll/delete', ensureRole('hod'), async (req, res) => {
  const { roll } = req.params;
  try {
    await Student.deleteOne({ rollNumber: roll });
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to delete student', err);
  }
  return res.redirect('/hod#manage-students');
});

app.post('/hod/faculty', ensureRole('hod'), async (req, res) => {
  const { name, facultyId, password, department, role } = req.body;
  if (!name || !facultyId || !password || !department) {
    return res.redirect('/hod#manage-faculty');
  }
  try {
    const hashed = await bcrypt.hash(password, 10);
    await Faculty.findOneAndUpdate(
      { facultyId: facultyId.trim() },
      {
        name: name.trim(),
        facultyId: facultyId.trim(),
        password: hashed,
        department: department.trim(),
        role: (role || 'faculty').trim(),
      },
      { upsert: true, new: true, setDefaultsOnInsert: true },
    );
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to upsert faculty', err);
  }
  return res.redirect('/hod#manage-faculty');
});

app.post('/hod/faculty/:facultyId/update', ensureRole('hod'), async (req, res) => {
  const { facultyId } = req.params;
  const { name, department, newFacultyId, password, role } = req.body;
  const update = {};
  if (name) update.name = name.trim();
  if (department) update.department = department.trim();
  if (newFacultyId) update.facultyId = newFacultyId.trim();
  if (role) update.role = role.trim();
  if (password) {
    try {
      update.password = await bcrypt.hash(password, 10);
    } catch (err) {
      // eslint-disable-next-line no-console
      console.error('Failed to hash password', err);
    }
  }
  try {
    await Faculty.findOneAndUpdate({ facultyId }, update, { new: true });
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to update faculty', err);
  }
  return res.redirect('/hod#manage-faculty');
});

app.post('/hod/faculty/:facultyId/delete', ensureRole('hod'), async (req, res) => {
  const { facultyId } = req.params;
  try {
    await Faculty.deleteOne({ facultyId });
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to delete faculty', err);
  }
  return res.redirect('/hod#manage-faculty');
});

app.post('/hod/subjects', ensureRole('hod'), async (req, res) => {
  const { subjectCode, subjectName, year, semester } = req.body;
  let { facultyIds, branches, branch } = req.body;
  if (!subjectCode || !subjectName) {
    return res.redirect('/hod#manage-subjects');
  }
  if (!Array.isArray(facultyIds) && typeof facultyIds === 'string' && facultyIds.length) {
    facultyIds = [facultyIds];
  }

  // Normalize branches input: support comma-separated values or single branch
  if (!Array.isArray(branches) && typeof branches === 'string' && branches.length) {
    branches = branches.split(',').map((b) => b.trim()).filter(Boolean);
  }
  const branchList = Array.isArray(branches)
    ? branches.filter(Boolean)
    : (branch ? [branch.trim()] : []);

  try {
    const trimmedCode = subjectCode.trim();
    const trimmedName = subjectName.trim();

    // Create or update one subject offering per branch so that
    // the same subject code can have different faculties per branch.
    const effectiveBranches = branchList.length ? branchList : [undefined];
    for (const br of effectiveBranches) {
      // eslint-disable-next-line no-await-in-loop
      const subject = await Subject.findOneAndUpdate(
        { subjectCode: trimmedCode, branch: br || undefined },
        {
          subjectCode: trimmedCode,
          subjectName: trimmedName,
          branch: br || undefined,
          branches: br ? [br] : [],
          year,
          semester,
          facultyIds: facultyIds || [],
        },
        { upsert: true, new: true, setDefaultsOnInsert: true },
      );
      // eslint-disable-next-line no-await-in-loop
      await ensureRequestsForSubject(subject);
      // eslint-disable-next-line no-await-in-loop
      await syncSubjectRequestsFaculty(subject);
    }
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to upsert subject(s)', err);
  }
  return res.redirect('/hod#manage-subjects');
});

app.post('/hod/subjects/:code/update', ensureRole('hod'), async (req, res) => {
  const { code } = req.params;
  const { subjectCode, subjectName, year, semester, originalBranch } = req.body;
  let { facultyIds, branches, branch } = req.body;
  if (!Array.isArray(facultyIds) && typeof facultyIds === 'string' && facultyIds.length) {
    facultyIds = [facultyIds];
  }
  // Normalize branches input (we use only the first branch value for this row)
  if (!Array.isArray(branches) && typeof branches === 'string' && branches.length) {
    branches = branches.split(',').map((b) => b.trim()).filter(Boolean);
  }
  const branchList = Array.isArray(branches)
    ? branches.filter(Boolean)
    : (branch ? [branch.trim()] : []);

  const newBranch = branchList[0] || undefined;
  const filter = { subjectCode: code };
  if (typeof originalBranch === 'string' && originalBranch.trim()) {
    filter.branch = originalBranch.trim();
  }

  try {
    const subject = await Subject.findOneAndUpdate(
      filter,
      {
        subjectCode: subjectCode?.trim() || code,
        subjectName: subjectName?.trim(),
        branch: newBranch,
        branches: newBranch ? [newBranch] : [],
        year,
        semester,
        facultyIds: facultyIds || [],
      },
      { new: true },
    );
    await ensureRequestsForSubject(subject);
    await syncSubjectRequestsFaculty(subject);
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to update subject', err);
  }
  return res.redirect('/hod#manage-subjects');
});

app.post('/hod/mentors/assign', ensureRole('hod'), async (req, res) => {
  const { mentorFacultyId, rollNumbers, mentorNotes } = req.body;
  if (!mentorFacultyId || !rollNumbers) {
    return res.redirect('/hod#manage-mentors');
  }

  const rolls = rollNumbers
    .split(',')
    .map((r) => r.trim())
    .filter(Boolean);

  try {
    await Student.updateMany(
      { rollNumber: { $in: rolls } },
      {
        mentorFacultyId: mentorFacultyId.trim(),
        ...(mentorNotes ? { mentorNotes: mentorNotes.trim() } : {}),
      },
    );
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to assign mentors', err);
  }
  return res.redirect('/hod#manage-mentors');
});

app.post('/hod/subjects/:code/delete', ensureRole('hod'), async (req, res) => {
  const { code } = req.params;
  const { originalBranch } = req.body;
  const filter = { subjectCode: code };
  if (typeof originalBranch === 'string' && originalBranch.trim()) {
    filter.branch = originalBranch.trim();
  }
  try {
    await Subject.deleteOne(filter);
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to delete subject', err);
  }
  return res.redirect('/hod#manage-subjects');
});

app.get('/admin', ensureRole('admin'), async (req, res) => {
  let allRequests = [];
  try {
    allRequests = await Request.find().sort({ createdAt: -1 }).lean();
    allRequests = allRequests.map((r) => ({ ...r, id: r._id.toString() }));
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to load admin requests', err);
  }

  res.render('adminDashboard', {
    pending: allRequests.filter((r) => r.status === 'Pending HOD'),
    all: allRequests,
  });
});

app.post('/admin/requests/:id/:action', ensureRole('admin'), async (req, res) => {
  const { id, action } = req.params;
  const { note } = req.body;
  let request;
  try {
    request = await Request.findById(id);
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to load request for admin action', err);
  }
  if (!request) return res.status(404).send('Request not found');
  if (request.status !== 'Pending HOD') return res.status(400).send('Request already processed');

  if (action === 'approve') {
    request.status = 'Approved';
    request.adminNote = note || 'Cleared by admin';
  } else if (action === 'deny') {
    request.status = 'Rejected by Admin';
    request.adminNote = note || 'Denied by admin';
  } else {
    return res.status(400).send('Invalid action');
  }

  try {
    await request.save();
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to update admin request status', err);
  }

  return res.redirect('/admin');
});

app.use((req, res) => {
  res.status(404).render('login', {
    error: 'Page not found. Please log in again.',
    searchError: null,
    searchResult: null,
  });
});

app.listen(PORT, () => {
  // eslint-disable-next-line no-console
  console.log(`nodue server listening on http://localhost:${PORT}`);
});
